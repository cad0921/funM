/* funM 調色（高爾夫）：飽和度、對比、色調、陰影／亮部分色、暗角、顆粒。
   由 branding/shaders/build_packs.py 產生，改這裡會被蓋掉。 */

vec3 funm_grade(vec3 c, vec2 uv) {
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 1.320);
    c = (c - 0.5) * 1.060 + 0.5;
    c *= vec3(0.970, 1.060, 0.930);
    c += vec3(0.000, 0.020, 0.000) * (1.0 - smoothstep(0.0, 0.5, l));
    c += vec3(0.020, 0.020, 0.000) * smoothstep(0.5, 1.0, l);
    vec2 d = uv - 0.5;
    c *= 1.0 - 0.100 * smoothstep(0.15, 0.75, dot(d, d) * 2.0);

    return clamp(c, 0.0, 1.0);
}
