#define FUNM_GOLF
#define VOXY_WATER

#include "/common/water_voxy_blocks_fragment.glsl"