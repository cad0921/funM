#version 120
#extension GL_ARB_shader_texture_lod : enable
#define FUNM_GOLF
/* MakeUp - gbuffers_textured.vsh
Render: Particles

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define GBUFFER_TEXTURED

#include "/common/solid_blocks_vertex.glsl"
