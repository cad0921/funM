/* funM 調色（搬運社）：飽和度、對比、色調、陰影／亮部分色、暗角、顆粒。
   由 branding/shaders/build_packs.py 產生，改這裡會被蓋掉。 */
uniform float frameTimeCounter;
vec3 funm_grade(vec3 c, vec2 uv) {
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 0.620);
    c = (c - 0.5) * 1.160 + 0.5;
    c *= vec3(0.940, 1.000, 1.020);
    c += vec3(-0.010, 0.025, 0.030) * (1.0 - smoothstep(0.0, 0.5, l));
    c += vec3(0.040, 0.015, -0.020) * smoothstep(0.5, 1.0, l);
    vec2 d = uv - 0.5;
    c *= 1.0 - 0.650 * smoothstep(0.15, 0.75, dot(d, d) * 2.0);
    c += (fract(sin(dot(uv * 1000.0 + fract(frameTimeCounter * 7.0), vec2(12.9898, 78.233))) * 43758.5453) - 0.5) * 0.045;
    return clamp(c, 0.0, 1.0);
}
