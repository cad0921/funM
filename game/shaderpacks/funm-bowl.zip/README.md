# MakeUp Ultra Fast
High performance Minecraft shader (Java).

## Version: 9.6

### This version works in Optifine and Iris 1.5.1 or higher.

## Main features
* Optional shadows
* Optional volumetric clouds
* Antialiasing (TAA)
* Depth of field
* Enhanced ambient occlusion
* Water reflection and refraction
* Motion blur
* Optional bloom
* Optional chromatic aberration
* Auto-exposure
* Shader for all native dimensions
* And more...
* FAST!

## Tested on:
* Minecraft 1.12.+ - 26.x
* Nvidia, AMD, Intel
* Windows and Linux

## You can:
* You can use the shader without restrictions.
* You can fork the shader from: [https://github.com/javiergcim/MakeUpUltraFast](https://github.com/javiergcim/MakeUpUltraFast)
* You can modify this shader for any purpose.
* If you modify or use the shader please add a credit, and the official URLs if possible: [https://modrinth.com/shader/makeup-ultra-fast-shaders](https://modrinth.com/shader/makeup-ultra-fast-shaders), [https://www.planetminecraft.com/mod/makeup-ultra-fast-shader/](https://www.planetminecraft.com/mod/makeup-ultra-fast-shader/), [https://www.curseforge.com/minecraft/customization/makeup-ultra-fast-shader](https://www.curseforge.com/minecraft/customization/makeup-ultra-fast-shader) and/or [https://github.com/javiergcim/MakeUpUltraFast](https://github.com/javiergcim/MakeUpUltraFast)

Notification is not required, but would be appreciated.


---
Modified for the funM server (style: bowl): per-pack style overrides in shaders/lib/config.glsl, colour grading in shaders/lib/funm_grade.glsl, extra dimension folder shaders/funm_peak. Original: MakeUp - UltraFast by Javier Garduño, LGPL-3.0 (see LICENSE).
