/* funM 調色（保齡球）：飽和度、對比、色調、陰影／亮部分色、暗角、顆粒。
   由 branding/shaders/build_packs.py 產生，改這裡會被蓋掉。 */

vec3 funm_grade(vec3 c, vec2 uv) {
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 1.650);
    c = (c - 0.5) * 1.140 + 0.5;
    c *= vec3(1.030, 0.960, 1.070);
    c += vec3(0.040, -0.010, 0.060) * (1.0 - smoothstep(0.0, 0.5, l));
    c += vec3(-0.020, 0.030, 0.040) * smoothstep(0.5, 1.0, l);
    vec2 d = uv - 0.5;
    c *= 1.0 - 0.350 * smoothstep(0.15, 0.75, dot(d, d) * 2.0);

    return clamp(c, 0.0, 1.0);
}
